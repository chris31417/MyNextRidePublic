<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
       <div class="VM_random">          

            <?php
            foreach ($rows as $row) {
                $rank_count = $rank_count + 1;    //start ranking
                $link1 = "index.php?option=com_vehiclemanager&amp;task=view_vehicle&amp;id="
                        . $row->id . "&amp;catid=" . $row->catid . "&amp;Itemid=" . $ItemId_tmp;


                $imageURL = $row->image_link;
                      if ($imageURL != '') {
            // quality of img from module  
            
            switch ($image_source_type) {
                case "0": $img_height = $vehiclemanager_configuration['fotoupload']['high'];
                    $img_width = $vehiclemanager_configuration['fotoupload']['width'];
                    break;
                case "1": $img_height = $vehiclemanager_configuration['fotomain']['high'];
                    $img_width = $vehiclemanager_configuration['fotomain']['width'];
                    break;
                case "2": $img_height = $vehiclemanager_configuration['fotogal']['high'];
                    $img_width = $vehiclemanager_configuration['fotogal']['width'];
                    break;
                default:$img_height = $vehiclemanager_configuration['fotoupload']['high'];
                    $img_width = $vehiclemanager_configuration['fotoupload']['width'];
                    break;
            }
            
            $imageURL1 = picture_thumbnail($imageURL, $img_height, $img_width);
            $imageURL = "./components/com_vehiclemanager/photos/" . $imageURL1;
        }
        else {
            $imageURL = "./components/com_vehiclemanager/images/no-img_eng.gif";
            
        }
                ?>
                <div class="random_line">
                    <?php if ($show_ranking == 1) {
                        echo "<div class='random_count'>" . $rank_count . ":&nbsp;</div>";
                    } //Add Column for Ranking if param set  ?>
                        <?php if ($show_covers == 1) { ?>
                        <div class='random_img'>
                            <a href="<?php echo sefRelToAbs($link1); ?>" target="_self" >
                                <img src="<?php echo $imageURL; ?>" alt="<?php echo $row->vtitle; ?>" hspace="2" vspace="2" border="0" 
                                     style="height:<?php echo $cover_height.'px'; ?>; width:<?php echo $cover_width.'px'; ?>;" />
                            </a>
                        </div>
                        <?php } ?>
                    <div class='random_title' <?php if ($span != 0) echo "colspan='$span'"; ?>>
                        <a href="<?php echo sefRelToAbs($link1); ?>" target="_self" ><?php echo $row->vtitle; ?></a>
                    <?php
                    if ($showprice == "1") {
                        echo "<br />";
                                    if ($vehiclemanager_configuration['price_unit_show'] == '1')
                                     if ($vehiclemanager_configuration['sale_separator'])
                                        echo formatMoney($row->price, false, $vehiclemanager_configuration['price_format']), ' ', $row->priceunit;
                                    else echo $row->price, ' ', $row->priceunit;
                                   else {
                                  if ($vehiclemanager_configuration['sale_separator'])
                                      echo $row->priceunit, ' ', formatMoney($row->price, false, $vehiclemanager_configuration['price_format']);
                                      else echo $row->priceunit, ' ', $row->price;
                                      }
                    } else {
                        echo "&nbsp;";
                    }
                    ?>
                    </div>
            <?php if ($show_extra == 1) { ?>
                        <div class='random_hits'>
                    <font class='small'>(<?php echo $row->hits; ?>)</font>
                    </div>
            <?php } ?>
                </div>
        <?php } ?>
        </div>