<?php
/**
 * Random 10 vehicles Module for vehiclemanager
 * @version 3.0
 * @package vehiclemanager
 * @copyright 2013 Andrey Kvasnevskiy-OrdaSoft(akbet@mail.ru); 
 */
defined('_JEXEC') or die('Restricted access');

if (!defined('DS'))
    define('DS', DIRECTORY_SEPARATOR);
require_once ( JPATH_BASE . DS . 'components' . DS . 'com_vehiclemanager' . DS . 'functions.php' );

$doc = JFactory::getDocument();
$doc->addStyleSheet(JURI::base(true) . '/' . 'components' . '/' . 'com_vehiclemanager' . '/' . 'includes' . '/' . 'vehiclemanager.css');



if (!function_exists('sefreltoabs')) {

    function sefRelToAbs($value) {
        //Need check!!!
        // Replace all &amp; with & as the router doesn't understand &amp;
        $url = str_replace('&amp;', '&', $value);
        if (substr(strtolower($url), 0, 9) != "index.php")
            return $url;
        $uri = JURI::getInstance();
        $prefix = $uri->toString(array('scheme', 'host', 'port'));
        return $prefix . JRoute::_($url);
    }

}
if (!function_exists('picture_thumbnail')){
    function picture_thumbnail($file, $high_original, $width_original) {
        

        // get name and type
        $file_inf = pathinfo($file);
        $tmp_type = explode(".", $file_inf['basename']);
        $file_type = "." . end($tmp_type);
        $file_name = basename($file_inf['basename'], $file_type);
        
        // Setting the resize parameters
        list($width, $height) = getimagesize('./components/com_vehiclemanager/photos/' . $file);

        $size = "_" . $high_original . "_" . $width_original;

        if (file_exists('./components/com_vehiclemanager/photos/' . $file_name . $size . $file_type)) {
            return $file_name . $size . $file_type;
        } else {
            if ($width < $height) {
                if ($height > $high_original) {
                    $k = $height / $high_original;
                } else if ($width > $width_original) {
                    $k = $width / $width_original;
                }
                else
                    $k = 1;
            } else {
                if ($width > $width_original) {
                    $k = $width / $width_original;
                } else if ($height > $high_original) {
                    $k = $height / $high_original;
                }
                else
                    $k = 1;
            }
            $w_ = $width / $k;
            $h_ = $height / $k;
        }

        // Creating the Canvas
        $tn = imagecreatetruecolor($w_, $h_);

        switch (strtolower($file_type)) {
            case '.png':
                $source = imagecreatefrompng('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagepng($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            case '.jpg':
                $source = imagecreatefromjpeg('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagejpeg($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            case '.jpeg':
                $source = imagecreatefromjpeg('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagejpeg($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);

                break;
            case '.gif':
                $source = imagecreatefromgif('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagegif($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            default:
                echo 'not support';
                return;
        }

        return $file_name . $size . $file_type;
    }
}

$s = vmLittleThings::getWhereUsergroupsCondition();

//Common parameters
$show_covers = $params->def('covers', 0);             //Get if we Real Estate  photos
$cover_height = $params->def('cover_height', "50");     //Get Real Estate  photos
$cover_width = $params->def('cover_width', "50");     //Get Real Estate  photos
$show_extra = $params->def('extras', 1);             //Get if we show second column with additional info
$show_ranking = $params->def('ranking', 0);             //Get if we show the ranking next to them
$showprice = $params->get('price', 1);
$count_vehicle = intval($params->def('count_vehicle', 1));
$ItemId_tmp_from_params = $params->get('ItemId');
$moduleclass_sfx = $params->get('moduleclass_sfx', '');
$layout = $params->get('layout', 'default');
$image_source_type = $params->get('image_source_type');
$GLOBALS['database'] = $database = JFactory::getDBO();
global $mosConfig_absolute_path, $mosConfig_allowUserRegistration, $mosConfig_lang, $database;
// load language
$languagelocale = "";
$query = "SELECT l.title, l.lang_code, l.sef ";
$query .= "FROM #__vehiclemanager_const_languages as cl ";
$query .= "LEFT JOIN #__vehiclemanager_languages AS l ON cl.fk_languagesid=l.id ";
$query .= "LEFT JOIN #__vehiclemanager_const AS c ON cl.fk_constid=c.id ";
$query .= "GROUP BY  l.title";
$database->setQuery($query);
$languages = $database->loadObjectList();

$lang = JFactory::getLanguage();

foreach ($lang->getLocale() as $locale) {
    foreach ($languages as $language) {
       
        if ($locale == $language->title || $locale == $language->lang_code || $locale == $language->sef)
        {
            $mosConfig_lang = $locale;
            $languagelocale = $language->lang_code;
            
            break;
        }
    }
}

if ($languagelocale == ''){
    $mosConfig_lang = $lang->getTag();
    $languagelocale = $lang->getTag();
}

if ($languagelocale == '')
    $languagelocale = "en-GB";

// Set content language
global $langContent;
if(isset($_REQUEST['lang'])) 
    {$langContent = $_REQUEST['lang'];
}else{
    $langContent = substr($languagelocale, 0, 2);
}

//Check if only display published items

    $where[] = " v.published=1 ";
    $where[] = " ($s) ";
        if (isset($langContent))
        {
            $lang = $langContent;
            $query = "SELECT lang_code FROM #__languages WHERE sef = '$lang'";
            $database->setQuery($query);
            $lang = $database->loadResult();
            $lang = " and (v.language like 'all' or v.language like '' or v.language like '*' or v.language is null or v.language like '$lang')
                     AND (c.language like 'all' or c.language like '' or c.language like '*' or c.language is null or c.language like '$lang') ";
        } else
        {
            $lang = "";
        }
if ($count_vehicle != '' && $count_vehicle != 0) {
    $selectstring = "SELECT v.vtitle,v.id,v.image_link,v.hits,c.id AS catid,price,priceunit
                    \nFROM #__vehiclemanager_vehicles as v
                    \nLEFT JOIN #__vehiclemanager_categories AS vc ON vc.iditem=v.id
                    \nLEFT JOIN #__vehiclemanager_main_categories AS c ON c.id=vc.idcat
                    \nWHERE" ." v.approved=1 AND " . implode(' AND ', $where) .$lang.
            "\nGROUP BY v.id " .
            "\nORDER BY rand()  DESC LIMIT 0,  $count_vehicle;";
    $database->setQuery($selectstring);
    $rows_vehicle = $database->loadObjectList();
}


$database->setQuery("SELECT id FROM #__menu WHERE link LIKE'%option=com_vehiclemanager%' AND params LIKE '%back_button%'");
$ItemId_tmp_from_db = $database->loadResult();

if ($ItemId_tmp_from_params == "") {
    $ItemId_tmp = $ItemId_tmp_from_db;
} else {
    $ItemId_tmp = $ItemId_tmp_from_params;
}

function DisplayVMR($rows, $name, $show_ranking, $show_covers, $show_extra, $cover_height, $cover_width, $ItemId_tmp, $showprice, $moduleclass_sfx, $layout, $image_source_type) {
    global $mosConfig_live_site, $mosConfig_absolute_path, $vehiclemanager_configuration;
    $rank_count = 0;
    $span = 0;
    if ($show_ranking != 0)
        $span++;
    if ($show_covers != 0)
        $span++;
    if ($show_extra != 0)
        $span++;
    ?>
    <noscript>Javascript is required to use Vehicle Manager <a href="http://ordasoft.com/Vehicle-Manager/vehiclemanager-basic-and-pro-feature-comparison.html">Vehicle manager software Joomla extension for Auto Dealers, Auto Dealership Companies and other Enterprises selling Vehicles
        </a>, <a href="http://ordasoft.com/Vehicle-Manager/vehiclemanager-basic-and-pro-feature-comparison.html">Vehicle Manager create own vehicle web portal for sell, rent,  buy vehicles</a></noscript>   
    <div class="vehiclemanager_<?php if ($moduleclass_sfx != '') echo $moduleclass_sfx; ?>">
 <?php 
if (version_compare(JVERSION, "3.0.0", "lt"))
    require(JModuleHelper::getLayoutPath('mod_vehiclemanager_random_pro', $layout)); else
    require (JModuleHelper::getLayoutPath('mod_vehiclemanager_random_pro_j3',$layout ));	
 ?>
        <?php
    }
    ?>


<?php
if (count($rows_vehicle)) {
    DisplayVMR($rows_vehicle, "Random  Vehicles", $show_ranking, $show_covers, $show_extra, $cover_height, $cover_width, $ItemId_tmp, $showprice, $moduleclass_sfx, $layout,$image_source_type);
}
?>
</div>

