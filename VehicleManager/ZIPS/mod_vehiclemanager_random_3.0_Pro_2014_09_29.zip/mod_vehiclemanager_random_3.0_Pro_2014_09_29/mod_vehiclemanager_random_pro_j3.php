<?php

include dirname(__FILE__)."/mod_vehiclemanager_random_pro.php";