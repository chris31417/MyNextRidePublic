<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="vehiclemanager_<?php if($moduleclass_sfx!='') echo $moduleclass_sfx ; ?>">
<div class="basictable">
	<?php foreach ($rows as $row) { 
	 $link1 ="index.php?option=com_vehiclemanager&amp;task=view_vehicle&amp;id=".$row->id."&amp;catid=".$row->catid."&amp;Itemid=".$ItemId_tmp;
	?>

       <div class="VM_top10_vehicle">
        <span class="VM_top10_title">
          <a href="<?php echo sefRelToAbs($link1); ?>"><?php echo $row->vtitle; ?></a>
       </span>
		   <span class="VM_top10_hits">
          <span class='small'>(<?php echo $row->hits; ?>)</span>
		   </span>
       </div>
  <?php } ?>
           
</div>
</div>