<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

if(count($vehicles) >0 ){
?>

<div class="vehiclemanager<?php if (isset($class_suffix)) echo $class_suffix;?>" >
    <div class="moduletable<?php echo "-".$class_suffix; ?> basictable"> 
    <?php
        $rank_count = 0;
        $span = 0;
        if ($status!=0) $span++;
        if ($show_image!=0) $span++;
        if ($show_hits!=0) $span++;

        if ($displaytype==1){ // Display Horizontal
    ?>
               <?php
        }

        foreach ($vehicles as $row){

                $query = "UPDATE #__vehiclemanager_vehicles SET featured_shows = featured_shows-1 WHERE  featured_shows > 0 and id=".$row->id;
                $database->setQuery($query);
                $database->query();


            $img = "";
            $rank_count = $rank_count + 1; //start ranking
            $link1 ="index.php?option=com_vehiclemanager&task=view_vehicle&id=".$row->id."&amp;catid=".$row->catid."&amp;Itemid=".$ItemId_tmp;
            $imageURL = $row->image_link;
     if ($imageURL != '') {
            // quality of img from module   
            $image_source_type = $params->get('image_source_type');
            switch ($image_source_type) {
                case "0": $img_height = $vehiclemanager_configuration['fotoupload']['high'];
                    $img_width = $vehiclemanager_configuration['fotoupload']['width'];
                    break;
                case "1": $img_height = $vehiclemanager_configuration['fotomain']['high'];
                    $img_width = $vehiclemanager_configuration['fotomain']['width'];
                    break;
                case "2": $img_height = $vehiclemanager_configuration['fotogal']['high'];
                    $img_width = $vehiclemanager_configuration['fotogal']['width'];
                    break;
                default:$img_height = $vehiclemanager_configuration['fotoupload']['high'];
                    $img_width = $vehiclemanager_configuration['fotoupload']['width'];
                    break;
            }            
            $imageURL1 = picture_thumbnail($imageURL, $img_height, $img_width);
            $imageURL = "./components/com_vehiclemanager/photos/" . $imageURL1;
        }
        else {
            $imageURL = "./components/com_vehiclemanager/images/no-img_eng.gif";
            
        }
            $img='<a href="'.$link1.'" target="_self"> <img src="'.$imageURL.'" alt="'.$row->vtitle.'" hspace="2" vspace="2" border="0" style="height:'.$image_height.'px; width:'.$image_width.'px" />';
            if ($displaytype==1){
                // Display Horizontal
    ?>
                    <div class="featured_vehicle_block">
                                <a href="<?php echo sefRelToAbs($link1); ?>" target="_self">
    <?php
                        if ($status==1) echo "<div class='featured_vehicle_count'>".$rank_count.":&nbsp;</div>";
                        if ($show_image==1) echo "<div class='featured_vehicle_img'>".$img."</div>";
    ?>
                            <div class="featured_vehicle_title" <?php if($span!=0) echo "colspan=".$span."";?> >
    <?php
                                if ($row->published!=1){
                                    $msg = " [ <tt style='color:red;font-size:10px;'>unpublished</tt> ] ";
                                    echo "<a target='' href='' style='cursor:default;' onClick='return false;'>".$row->vtitle."</a>";
                                } else{
                                    $msg = '';
                                    echo "<a href='".sefRelToAbs($link1)."' target='_self'>".$row->vtitle."</a>";
                                }

    ?>
                            </div>

    <?php
                        if ($status == "1"){
                            // Get the rent status
                            $query = "SELECT b.rent_from, b.rent_until 
                                      FROM #__vehiclemanager_rent AS b 
                                      LEFT JOIN #__vehiclemanager_vehicles AS c ON b.fk_vehicleid = c.id 
                                      WHERE c.id=".$row->id." 
                                      AND c.published='1' AND c.approved='1' AND b.rent_return IS NULL";
                            $database->setQuery($query);
                            $rent = $database->loadObjectList();
                            if (isset($rent[0]->rent_from)){
                                echo "<tr><td><br /><tt> rented from ".$rent[0]->rent_from;
                                echo "<br /> to ".$rent[0]->rent_until;
                                echo "</tt></td></tr>";
                            }
                        }
                        if ($model == 1) echo "<div class='featured_vehicle_model'>{$row->vmodel}&nbsp;</div>";
                        if ($price == 1) {
						  echo "<div class='featured_vehicle_price'>";
						  if ($vehiclemanager_configuration['price_unit_show'] == '1')
                                     if ($vehiclemanager_configuration['sale_separator'])
                                        echo formatMoney($row->price, false, $vehiclemanager_configuration['price_format']), ' ', $row->priceunit;
                                    else echo $row->price, ' ', $row->priceunit;
						  else {
                                  if ($vehiclemanager_configuration['sale_separator'])
                                      echo $row->priceunit, ' ', formatMoney($row->price, false, $vehiclemanager_configuration['price_format']);
                                      else echo $row->priceunit, ' ', $row->price;
                         }
                         echo "</div>";
						}
                        if ($show_hits == 1) echo "<div class='featured_vehicle_hits'><a>({$row->hits})</a></div>"; else echo "&nbsp;";

    ?>
                   </div>
    <?php
            } else{
                //Display Vertical
    ?>

                <div class="featured_vehicle_line">
                        <a href="<?php echo sefRelToAbs($link1); ?>" target="_self">
    <?php
                        if ($status==1) echo "<div class='featured_vehicle_count featured_vehicle_inline'>".$rank_count.":&nbsp;</div>";
                        if ($show_image==1) echo "<div class='featured_vehicle_img featured_vehicle_inline'>".$img."</div>";
    ?>
                    <div class="featured_vehicle_title featured_vehicle_inline" <?php if($span!=0) echo "colspan='".$span."'";?> >
    <?php
                        if ($row->published!=1){
                            $msg = " [ <tt style='color:red;font-size:10px;'>unpublished</tt> ] ";
                            echo "<a target='' href='' style='cursor:default;' onClick='return false;'>".$row->vtitle."</a>";
                        } else{
                            $msg = ''; 
                            echo "<a href='".sefRelToAbs($link1)."' target='_self' >".$row->vtitle."</a>";
                        }
    ?>
                    </div>
        <?php
                        if ($model == 1) echo "<div class='featured_vehicle_model featured_vehicle_inline '>{$row->vmodel}&nbsp;</div>";
                       if ($price == 1) { echo "<div class='featured_vehicle_price featured_vehicle_inline '>";
                        if ($vehiclemanager_configuration['price_unit_show'] == '1')
                                     if ($vehiclemanager_configuration['sale_separator'])
                                        echo formatMoney($row->price, false, $vehiclemanager_configuration['price_format']), ' ', $row->priceunit;
                                    else echo $row->price, ' ', $row->priceunit;
                         else {
                                  if ($vehiclemanager_configuration['sale_separator'])
                                      echo $row->priceunit, ' ', formatMoney($row->price, false, $vehiclemanager_configuration['price_format']);
                                      else echo $row->priceunit, ' ', $row->price;
                         }
                                      echo "</div>";
						}
                        if ($show_hits == 1) echo "<div class='featured_vehicle_hits featured_vehicle_inline '>({$row->hits})</div>"; else echo "&nbsp;";
    ?>
                </div>
    <?php
            }
        }
        if ($displaytype==1){ // Display Horizontal
    ?>
    <?php
        }
    ?>
                <div>&nbsp;</div>
    </div>
</div>
<?php
}
?>
