<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * @package VehicleManager
 * @copyright 2012 OrdaSoft
 * @author 2012 Andrey Kvasnevskiy-OrdaSoft(akbet@mail.ru)
 * Homepage: http://www.ordasoft.com
*/
if (!defined('DS'))
    define('DS', DIRECTORY_SEPARATOR);
global $vehiclemanager_configuration;
$database = $GLOBALS['database'] = JFactory::getDBO();
$mosConfig_absolute_path = $GLOBALS['mosConfig_absolute_path']  = JPATH_SITE;
global $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_allowUserRegistration, $mosConfig_lang;

// load language
$languagelocale = "";
$query = "SELECT l.title, l.lang_code, l.sef ";
$query .= "FROM #__vehiclemanager_const_languages as cl ";
$query .= "LEFT JOIN #__vehiclemanager_languages AS l ON cl.fk_languagesid=l.id ";
$query .= "LEFT JOIN #__vehiclemanager_const AS c ON cl.fk_constid=c.id ";
$query .= "GROUP BY  l.title";
$database->setQuery($query);
$languages = $database->loadObjectList();

$lang = JFactory::getLanguage();

foreach ($lang->getLocale() as $locale) {
    foreach ($languages as $language) {
       
        if ($locale == $language->title || $locale == $language->lang_code || $locale == $language->sef)
        {
            $mosConfig_lang = $locale;
            $languagelocale = $language->lang_code;
            
            break;
        }
    }
}

if ($languagelocale == ''){
    $mosConfig_lang = $lang->getTag();
    $languagelocale = $lang->getTag();
}

if ($languagelocale == '')
    $languagelocale = "en-GB";

// Set content language
global $langContent;
if(isset($_REQUEST['lang'])) 
    {$langContent = $_REQUEST['lang'];
}else{
    $langContent = substr($languagelocale, 0, 2);
}

$doc =JFactory::getDocument();
$doc->addStyleSheet(JURI::base(true) .'/'.  'components'.'/'.'com_vehiclemanager'.'/'.'includes'.'/'.'vehiclemanager.css');

$file = "functions.php";
$f_path = JPATH_BASE .DS.'components'.DS.'com_vehiclemanager'.DS.'functions.php';
if (!file_exists($f_path)){
    echo "To display the featured books You have to install VehicleManager first<br />"; exit; 
} else require_once ($f_path);

if (!function_exists('sefreltoabs')){
    function sefRelToAbs($value){
        // Replace all &amp; with & as the router doesn't understand &amp;
        $url = str_replace('&amp;', '&', $value);//replace chars &amp; on & in 
        if(substr(strtolower($url),0,9) != "index.php") return $url;//cheking correct url
        $uri = JURI::getInstance();
        $prefix = $uri->toString(array('scheme', 'host', 'port'));
        return $prefix.JRoute::_($url);
    }
}

//Common parameters
$show_image = $params->get('image', 0);
$image_height = $params->get('image_height', "50");
$image_width = $params->get('image_width', "50");
$show_hits = $params->get('hits', 1);
$price = $params->get('price', 0 );
$status =  $params->get('status', 0);
$model = $params->get('model', 0);
//Individual parameters
$count = intval($params->get('count',1));
$cat_id = $params->get('cat_id',"0");
$vehicle_id = $params->get('vehicle_id',"0");
//Display type
$displaytype = $params->get ('displaytype', 0);

//Advanced parameters
$class_suffix = $params->get('moduleclass_sfx','');
$ItemId_tmp_from_params=$params->get('ItemId');


//Check if only display published items
 $sql_published = "published=1";
 $sql_approved = " AND v.approved=1";
 
$cat_sel="";
$vehicle_ids="";
if ($cat_id!=0 && $show_published == 1){
    $cat_sel=" and c.id in (".$cat_id.")";
} else if($cat_id!=0 && $show_published == 0 ){
    $cat_sel=" c.id in (".$cat_id.")";
} else if ($cat_id==0){
    if ($vehicle_id!=0 && $show_published == 1) {
        $vehicle_ids=" and v.id in (".$vehicle_id.")";
    } else if ($vehicle_id!=0 && $show_published == 0){
        $vehicle_ids=" v.id in (".$vehicle_id.")";
    }
}
if (!function_exists('picture_thumbnail')){
    function picture_thumbnail($file, $high_original, $width_original) {
        

        // get name and type
        $file_inf = pathinfo($file);
        $tmp_type = explode(".", $file_inf['basename']);
        $file_type = "." . end($tmp_type);
        $file_name = basename($file_inf['basename'], $file_type);
        
        // Setting the resize parameters
        list($width, $height) = getimagesize('./components/com_vehiclemanager/photos/' . $file);

        $size = "_" . $high_original . "_" . $width_original;

        if (file_exists('./components/com_vehiclemanager/photos/' . $file_name . $size . $file_type)) {
            return $file_name . $size . $file_type;
        } else {
            if ($width < $height) {
                if ($height > $high_original) {
                    $k = $height / $high_original;
                } else if ($width > $width_original) {
                    $k = $width / $width_original;
                }
                else
                    $k = 1;
            } else {
                if ($width > $width_original) {
                    $k = $width / $width_original;
                } else if ($height > $high_original) {
                    $k = $height / $high_original;
                }
                else
                    $k = 1;
            }
            $w_ = $width / $k;
            $h_ = $height / $k;
        }

        // Creating the Canvas
        $tn = imagecreatetruecolor($w_, $h_);

        switch (strtolower($file_type)) {
            case '.png':
                $source = imagecreatefrompng('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagepng($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            case '.jpg':
                $source = imagecreatefromjpeg('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagejpeg($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            case '.jpeg':
                $source = imagecreatefromjpeg('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagejpeg($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);

                break;
            case '.gif':
                $source = imagecreatefromgif('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagegif($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            default:
                echo 'not support';
                return;
        }

        return $file_name . $size . $file_type;
    }
} 
if($cat_id!=0 && $vehicle_id!=0){
    echo ('<font color="#CC0000">You input IDs of categories and vehicles together! Correct this mistake.</font>');
}

$s = vmLittleThings::getWhereUsergroupsCondition("c");

        if (isset($langContent))
        {
            $lang = $langContent;
            $query = "SELECT lang_code FROM #__languages WHERE sef = '$lang'";
            $database->setQuery($query);
            $lang = $database->loadResult();
            $lang = " and (v.language like 'all' or v.language like '' or v.language like '*' or v.language is null or v.language like '$lang')
                     AND (c.language like 'all' or c.language like '' or c.language like '*' or c.language is null or c.language like '$lang') ";
        } else
        {
            $lang = "";
        }
        
$q = "SELECT v.vtitle, v.id, v.image_link, v.hits, c.id AS catid, v.price, v.published, v.priceunit, v.vmodel, v.vtitle, v.featured_clicks, v.featured_shows
        \n FROM `#__vehiclemanager_vehicles` as v
        \n LEFT JOIN `#__vehiclemanager_categories` AS vc ON v.id=vc.iditem
        \n LEFT JOIN `#__vehiclemanager_main_categories` AS c ON c.id=vc.idcat
        \n WHERE (".$s.")$lang and ( v.featured_clicks > 0 or v.featured_shows > 0 )  ";
$query_flag = true;
if ((isset($count) AND $count > 0) AND $cat_sel == "" AND $vehicle_ids != ""){
    // Set [vehicles IDs] and [published] = 'Show all'
    ///echo "[1]";   
    $vehicle_ids = " AND " . $vehicle_ids;
} elseif ((isset($count) AND $count > 0) AND $cat_sel == "" AND $vehicle_ids != ""){
    // If [vehicles IDs] was given and [published] = 'Show published'
    ///echo "[2]";
    $q .= " AND c.".$sql_published." AND v.".$sql_published;
} elseif ((isset($count) AND $count > 0) AND $cat_sel != "" AND $vehicle_ids == ""){
    // If [catid] was given and [published] = 'Show all'
    ///echo "[3]";
    $cat_sel = " AND ".$cat_sel;
} elseif ((isset($count) AND $count > 0) AND $cat_sel != "" AND $vehicle_ids == "" ){
    // If [catid] was given and [published] = 'Show published'
    ///echo "[4]";
    $q .= " AND c.".$sql_published." AND v.".$sql_published;
}
  elseif ((isset($count) AND $count > 0) AND $cat_sel == "" AND $vehicle_ids == "" ){
    // If [catid, vehicles IDs] was NOT given and [published] = 'Show published'
    ///echo "[6]";
    // Just display last [count] of published vehicles only
    $q .= " AND c.".$sql_published." AND v.".$sql_published;
} else{
    // If [catid, vehicles ID] was given or NOT, [published] = 'Show all'/'Show published' 
    // and [Count of vehicles] = 0
    $query_flag = false;
    $vehicles = "";
    echo "Any vehicle was not displayed";
}

$q .= $cat_sel.$vehicle_ids.$sql_approved." GROUP BY v.id ORDER BY v.hits DESC LIMIT 0 , ".$count.";";

if ($query_flag){
    $database->setQuery($q);
    $vehicles= $database->loadObjectList();
}
if(count($vehicles) <= 0) return;

$database->setQuery("SELECT id FROM #__menu WHERE link LIKE'%option=com_vehiclemanager%' AND params LIKE '%back_button%'");$ItemId_tmp_from_db = $database->loadResult();  
if($ItemId_tmp_from_params!=''){
    $ItemId_tmp=$ItemId_tmp_from_params;
} else{
    $ItemId_tmp=$ItemId_tmp_from_db;
}
?>
<?php 
if (version_compare(JVERSION, "3.0.0", "lt"))
    require(JModuleHelper::getLayoutPath('mod_vehiclemanager_featured_pro', $params->get('layout', 'default'))); else
    require (JModuleHelper::getLayoutPath('mod_vehiclemanager_featured_pro_j3', $params->get('layout', 'default')));	
 ?>
