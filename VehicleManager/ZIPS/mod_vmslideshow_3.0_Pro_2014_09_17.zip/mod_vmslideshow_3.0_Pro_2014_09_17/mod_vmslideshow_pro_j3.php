<?php


include dirname(__FILE__)."/mod_vmslideshow_pro.php";