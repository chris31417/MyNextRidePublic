<?php

include dirname(__FILE__)."/mod_vehiclemanager_location_map_pro.php";