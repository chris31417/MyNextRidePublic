<?php
/**
 * @version 2.2
 * @package VehicleManager LocationMap
 * @copyright 2009 OrdaSoft
 * @author 2009 Sergey Brovko-OrdaSoft(brovinho@mail.ru)
 * @description Location map for VehicleManager
*/
if (!defined('DS'))
    define('DS', DIRECTORY_SEPARATOR);
if(version_compare(JVERSION, "3.0.0","lt"))
JHTML::_('behavior.mootools');
else {
   JHTML::_('behavior.framework', true); 
}
$pr = rand();
?>
<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

if( !function_exists( 'sefreltoabs')) {
  function sefRelToAbs( $value ) {


    // Replace all &amp; with & as the router doesn't understand &amp;
    $url = str_replace('&amp;', '&', $value);//replace chars &amp; on & in 
    if(substr(strtolower($url),0,9) != "index.php") return $url;//cheking correct url
	
    $uri    = JURI::getInstance();
	 $prefix = $uri->toString(array('scheme', 'host', 'port'));
    return $prefix.JRoute::_($url);
  }
}

//Common parameters
//Individual parameters
$count_vehicles = intval($params->def('vehicles', 0));
$cat_id = $params->get('cat_id');
$vehicle_id = $params->get('vehicle_id');
$new_target = $params->def('new_target', 1);
$ItemId_tmp_from_params = $params->get('ItemId');
$moduleclass_sfx = $params->get('moduleclass_sfx');

$database = JFactory::getDBO();
$my=JFactory::getUser();
$GLOBALS['database'] = &$database;
$GLOBALS['my']=&$my;
$acl =JFactory::getACL();
$GLOBALS['acl'] =$acl;
$mosConfig_absolute_path = $GLOBALS['mosConfig_absolute_path']  = JPATH_SITE;

require_once ( JPATH_SITE . "/components/com_vehiclemanager/functions.php" );

$database = JFactory::getDBO() ;
// load language
$languagelocale = "";
$query = "SELECT l.title, l.lang_code, l.sef ";
$query .= "FROM #__vehiclemanager_const_languages as cl ";
$query .= "LEFT JOIN #__vehiclemanager_languages AS l ON cl.fk_languagesid=l.id ";
$query .= "LEFT JOIN #__vehiclemanager_const AS c ON cl.fk_constid=c.id ";
$query .= "GROUP BY  l.title";
$database->setQuery($query);
$languages = $database->loadObjectList();

$lang = JFactory::getLanguage();

foreach ($lang->getLocale() as $locale) {
    foreach ($languages as $language) {
       
        if ($locale == $language->title || $locale == $language->lang_code || $locale == $language->sef)
        {
            $mosConfig_lang = $locale;
            $languagelocale = $language->lang_code;
            
            break;
        }
    }
}

if ($languagelocale == ''){
    $mosConfig_lang = $lang->getTag();
    $languagelocale = $lang->getTag();
}

if ($languagelocale == '')
    $languagelocale = "en-GB";

// Set content language
global $langContent;
if(isset($_REQUEST['lang'])) 
    {$langContent = $_REQUEST['lang'];
}else{
    $langContent = substr($languagelocale, 0, 2);
}

$s = vmLittleThings::getWhereUsergroupsCondition ();

   $query = "SELECT language FROM #__modules WHERE id = '$module->id'";
   $database->setQuery($query);
   $langmodule = $database->loadResult();
   
 $sql_published = " AND v.published=1";
 $sql_approved = " AND v.approved=1";

if ($cat_id != null && $vehicle_id != null)
echo ('<font color="#CC0000">You input IDs of categories and vehicles together! Correct this mistake.</font>');
else
{
   if($vehicle_id != null) $sql_where = " AND v.id IN(".$vehicle_id.")";
   if($cat_id != null) $sql_where = " AND c.id IN(".$cat_id.")";
   if($cat_id == null && $vehicle_id == null) $sql_where = "";

   if (isset($langContent))
        {
            $lang = $langContent;
            $query = "SELECT lang_code FROM #__languages WHERE sef = '$lang'";
            $database->setQuery($query);
            $lang = $database->loadResult();
            $lang = " and (v.language like 'all' or v.language like '' or v.language like '*' or v.language is null or v.language like '$lang')
                     AND (c.language like 'all' or c.language like '' or c.language like '*' or c.language is null or c.language like '$lang') ";
        } else
        {
            $lang = "";
        }
        
   if($langmodule != "" && $langmodule != "*"){
          $selectstring = "SELECT v.vtitle,v.id,v.vehicleid,v.vlatitude,v.vlongitude,vc.idcat
                    \nFROM #__vehiclemanager_vehicles AS v
                    \nLEFT JOIN #__vehiclemanager_categories AS vc ON vc.iditem=v.id
                    \nLEFT JOIN #__vehiclemanager_main_categories AS c ON c.id=vc.idcat
                    \nWHERE ($s) $lang AND v.language = '".$langmodule."' AND v.vlatitude IS NOT NULL".$sql_where.$sql_published.$sql_approved.
                   "\nLIMIT ".$count_vehicles;
   }
   else{
          $selectstring = "SELECT v.vtitle,v.id,v.vehicleid,v.vlatitude,v.vlongitude,vc.idcat
                    \nFROM #__vehiclemanager_vehicles AS v
                    \nLEFT JOIN #__vehiclemanager_categories AS vc ON vc.iditem=v.id
                    \nLEFT JOIN #__vehiclemanager_main_categories AS c ON c.id=vc.idcat
                    \nWHERE ($s) $lang AND v.vlatitude IS NOT NULL".$sql_where.$sql_published.$sql_approved.
                   "\nLIMIT ".$count_vehicles;
   }
            $database->setQuery($selectstring);
            $rows= $database->loadObjectList();

$selectstring = "SELECT id  FROM #__menu WHERE   link LIKE'%option=com_vehiclemanager%' AND params LIKE '%back_button%'  ";
$database->setQuery($selectstring);
$ItemId_tmp_from_db = $database->loadResult();
if($ItemId_tmp_from_params==""){
  $ItemId_tmp=$ItemId_tmp_from_db;
}
else{
  $ItemId_tmp=$ItemId_tmp_from_params;
}


}
?>
<?php 
if (version_compare(JVERSION, "3.0.0", "lt"))
    require(JModuleHelper::getLayoutPath('mod_vehiclemanager_location_map_pro', $params->get('layout', 'default'))); else
    require (JModuleHelper::getLayoutPath('mod_vehiclemanager_location_map_pro_j3', $params->get('layout', 'default')));	
 ?>