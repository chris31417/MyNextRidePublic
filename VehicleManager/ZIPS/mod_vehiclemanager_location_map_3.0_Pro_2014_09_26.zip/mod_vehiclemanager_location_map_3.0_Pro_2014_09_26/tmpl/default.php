<?php 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="vehiclemanager_<?php if($moduleclass_sfx!='') echo $moduleclass_sfx; ?>">
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false" ></script>
<script type="text/javascript">
window.addEvent('domready', function() {
    var marker = new Array();
    var myOptions = {
       zoom:  1,
       center: new google.maps.LatLng(<?php if ($rows[0]->vlatitude) echo $rows[0]->vlatitude; else echo 0; ?>,
       <?php if ($rows[0]->vlongitude) echo $rows[0]->vlongitude; else echo 0; ?>),
       <?php if ($params->get('menu_map') == 0) echo "mapTypeControl: false,"; else echo "mapTypeControl: true,";?>
       <?php if ($params->get('control_map') == 0) echo "zoomControl: false, panControl: false, streetViewControl: false,";
             else echo "zoomControl: true, panControl: true, streetViewControl: true,";?>
             
       mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    var map_mod_vehicle = new google.maps.Map(document.getElementById("map_canvas<?php echo $pr; ?>"), myOptions);
     var bounds = new google.maps.LatLngBounds ();
    
    <?php  
     $j=0; 
     for ($i = 0; $i < count($rows); $i++)
     { ?>
    
     <?php
     
      if(isset($rows[$i]->vlatitude) & isset($rows[$i]->vlongitude) & $rows[$i]->vlatitude !='' & $rows[$i]->vlongitude !='')
      {
       ?>
        
	marker.push(new google.maps.Marker({
        position: new google.maps.LatLng(<?php echo $rows[$i]->vlatitude; ?>, <?php echo $rows[$i]->vlongitude; ?>),
        map: map_mod_vehicle,
	title: "<?php echo $rows[$i]->vtitle; ?>"
	
	}));
	
	bounds.extend(new google.maps.LatLng(<?php echo $rows[$i]->vlatitude; ?>, <?php echo $rows[$i]->vlongitude; ?>));
	google.maps.event.addListener(marker[<?php echo $j; ?>], 'click', function() {
	
	if(<?php echo $new_target; ?> == 1) window.open("index.php?option=com_vehiclemanager&task=view_vehicle&id=<?php echo $rows[$i]->id; ?>&catid=<?php echo $rows[$i]->idcat; ?>&Itemid=<?php echo $ItemId_tmp;?>");
	else document.location = "index.php?option=com_vehiclemanager&task=view_vehicle&id=<?php echo $rows[$i]->id; ?>&catid=<?php echo $rows[$i]->idcat; ?>&Itemid=<?php echo $ItemId_tmp;?>";
	});
     <?php
      $j++;
     }
     ?>
     
     <?php
     }
     ?>
     
     if( marker.lenght > 0 ) map_mod_vehicle.setCenter(bounds.getCenter());
     map_mod_vehicle.fitBounds(bounds);
});
</script>
<div id="map_canvas<?php echo $pr; ?>" style=
      "width: <?php echo $params->get('map_width');?>px; height: <?php echo $params->get('map_height'); ?>px;
      border: 1px solid black; float: rigth;" >
  </div>
<br>

</div>
 <style type="text/css">
    #map_canvas<?php echo $pr; ?> img{
        max-width: none;
    }
</style> 
