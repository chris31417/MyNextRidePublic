<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

?>

 <div class="vehiclemanager_<?php if ($class_suffix != '') echo $class_suffix; ?>" >
    <ul class="similaire">
<?php 

foreach ($list as $item){

?>
        <li style="<?=$listestyle;?>">
            <div class="miniature" style="<?=$miniature?>">
            <?php
              $imageURL = $item->image_link; // name with type

        if ($imageURL != '') {
            // quality of img from module
            
            switch ($image_source_type) {
                case "0": $img_height = $vehiclemanager_configuration['fotoupload']['high'];
                    $img_width = $vehiclemanager_configuration['fotoupload']['width'];
                    break;
                case "1": $img_height = $vehiclemanager_configuration['fotomain']['high'];
                    $img_width = $vehiclemanager_configuration['fotomain']['width'];
                    break;
                case "2": $img_height = $vehiclemanager_configuration['fotogal']['high'];
                    $img_width = $vehiclemanager_configuration['fotogal']['width'];
                    break;
                default:$img_height = $vehiclemanager_configuration['fotoupload']['high'];
                    $img_width = $vehiclemanager_configuration['fotoupload']['width'];
                    break;
            }
           
            $imageURL1 = picture_thumbnail($imageURL, $img_height, $img_width);
            $imageURL = "./components/com_vehiclemanager/photos/" . $imageURL1;
        }
        else {
            $imageURL = "./components/com_vehiclemanager/images/no-img_eng.gif";
            
        }
  ?>

                    <?php
                    $idvehi = $item->id;
                    $database = JFactory::getDBO();
                    $query = "SELECT v.priceunit FROM `#__vehiclemanager_vehicles` AS v WHERE id=(" . $idvehi . ")";
                    $database->setQuery($query);
                    $priceunit = $database->loadResult();
                    ?>
                    <a href="index.php?option=com_vehiclemanager&task=view_vehicle&id=<?php echo $item->id; ?>&catid=<?php echo $item->cid; ?>&Itemid=<?= $ItemId_tmp; ?>" title="<?php echo $item->link; ?>">
                        <img  style="width:90px;" src="<?php echo $imageURL ?>" alt="<?php echo $item->link; ?>" />
                    </a>
                </div>
                <div>
                    <h3 style="<?=$h3;?>""><?php echo $item->maker; ?></h3>
                    <h4 style="<?=$h4;?>"><?php echo $item->vmodel; ?></h4>
                    <h4>
                    <?php
                    if ($item->year != '') {
                        echo $item->year;
                    }
                    ?>
                    <?php
                    if ($item->fuel_type != '') {
                        echo ' / ' . $item->fuel_type;
                    }
                    ?>
                    <?php
                    if ($item->mileage != '') {
                        echo ' / ' . $item->mileage . 'mileage';
                    }
                    ?>
                    </h4>
    <?php if ($item->price != ''){ 
	          if ($vehiclemanager_configuration['price_unit_show'] == '1')
              if ($vehiclemanager_configuration['sale_separator']){?>
                <span class="prix" style="<?=$prix; ?>"><?php   echo formatMoney($item->price, false, $vehiclemanager_configuration['price_format']), ' ', $priceunit;?></span>
        <?php }
              else {?>
                      <span class="prix" style="<?=$prix; ?>"><?php    echo $item->price, ' ', $priceunit;?></span>
             <?php }
                   else {
                    if ($vehiclemanager_configuration['sale_separator']){ ?>
                      <span class="prix" style="<?=$prix; ?>"><?php  echo $priceunit, ' ', formatMoney($item->price, false, $vehiclemanager_configuration['price_format']);?></span>
             <?php  }
                    else {?>
                      <span class="prix" style="<?=$prix; ?>"><?php echo $priceunit, ' ', $item->price;?></span>
          <?php     }
                  }
          } ?>
                </div>
            </li>
<?php 
};
 ?>
        
    </ul>
    
    
</div>