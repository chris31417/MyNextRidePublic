<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
       <div class="block_list">          
         
    <?php foreach ($rows as $row) {
        $rank_count = $rank_count + 1;    //start ranking
        $link1 ="index.php?option=com_vehiclemanager&amp;task=view_vehicle&amp;id="
          .$row->id."&amp;catid=".$row->catid."&amp;Itemid=".$ItemId_tmp;
    
    
        $imageURL = $row->image_link ;
        
       if ($imageURL != '') {
            // quality of img from module   
            
            switch ($image_source_type) {
                case "0": $img_height = $vehiclemanager_configuration['fotoupload']['high'];
                    $img_width = $vehiclemanager_configuration['fotoupload']['width'];
                    break;
                case "1": $img_height = $vehiclemanager_configuration['fotomain']['high'];
                    $img_width = $vehiclemanager_configuration['fotomain']['width'];
                    break;
                case "2": $img_height = $vehiclemanager_configuration['fotogal']['high'];
                    $img_width = $vehiclemanager_configuration['fotogal']['width'];
                    break;
                default:$img_height = $vehiclemanager_configuration['fotoupload']['high'];
                    $img_width = $vehiclemanager_configuration['fotoupload']['width'];
                    break;
            }
            
            $imageURL1 = picture_thumbnail($imageURL, $img_height, $img_width);
            $imageURL = "./components/com_vehiclemanager/photos/" . $imageURL1;
        }
        else {
            $imageURL = "./components/com_vehiclemanager/images/no-img_eng.gif";
            
        }

?>
    <div class="block_list_in" style="background:<?php echo $body_colortop  ?>; float:<?php if ($displaytypetop==1) { echo "left";} else {echo "none";} ?>;">
           <?php if ($show_covers==1) {?>
          <div class="block_list_img">
            <a href="<?php echo $link1; ?>"><img src="<?php echo $imageURL; ?>" alt="<?php echo $row->vtitle; ?>" hspace="2" vspace="2" border="0" 
               style="height:<?php echo $cover_height."px"; ?>" /></a>
          </div>
           <?php  } ?>
          <div class="block_list_model">
              <a href="<?php echo sefRelToAbs( $link1 ); ?>" target="_self""><?php echo $row->vtitle; ?></a>
     </div>
     
     
     <div class="priceAndHits">
       <div class="block_list_price">
       <p>
       <?php 
        if ($showprice == "1") {
          if ($vehiclemanager_configuration['price_unit_show'] == '1'){
                  if ($vehiclemanager_configuration['sale_separator'])
                    echo _VEHICLE_MANAGER_LABEL_PRICE . ": " .
                      formatMoney($row->price, true, $vehiclemanager_configuration['price_format']), ' ',
                        $row->priceunit;
                else _VEHICLE_MANAGER_LABEL_PRICE . ": " .$row->price.'&nbsp;'.$row->priceunit;
          }
          else {
              if ($vehiclemanager_configuration['sale_separator'])
                  echo _VEHICLE_MANAGER_LABEL_PRICE . ": " .$row->priceunit, ' ',
                    formatMoney($row->price, true, $vehiclemanager_configuration['price_format']);
                  else _VEHICLE_MANAGER_LABEL_PRICE . ": " .$row->priceunit.'&nbsp;'.$row->price;
          }
        }  
        ?>
        </p>
        </div>
              <?php if($show_extra==1) {?>
        <div class="block_list_hits">
           <p><?php echo _VEHICLE_MANAGER_LABEL_HITS .": ". $row->hits; ?></p>
        </div>
          
            <?php } ?>
          </div>

     </div>
<?php } ?>
        </div>