<?php
/**
 * @version 2.2
 * @package VehicleManagerTop
 * @copyright 2011 OrdaSoft
 * @description VehicleTop for VehicleManager Component
*/

/** ensure this file is being included by a parent file */
defined( '_JEXEC' ) or die( 'Restricted access' );
if (!defined('DS'))
    define('DS', DIRECTORY_SEPARATOR);
require_once ( JPATH_BASE .DS.'components'.DS.'com_vehiclemanager'.DS.'functions.php' );


$database = JFactory::getDBO();
// load language
$languagelocale = "";
$query = "SELECT l.title, l.lang_code, l.sef ";
$query .= "FROM #__vehiclemanager_const_languages as cl ";
$query .= "LEFT JOIN #__vehiclemanager_languages AS l ON cl.fk_languagesid=l.id ";
$query .= "LEFT JOIN #__vehiclemanager_const AS c ON cl.fk_constid=c.id ";
$query .= "GROUP BY  l.title";
$database->setQuery($query);
$languages = $database->loadObjectList();

$lang = JFactory::getLanguage();

foreach ($lang->getLocale() as $locale) {
    foreach ($languages as $language) {
       
        if ($locale == $language->title || $locale == $language->lang_code || $locale == $language->sef)
        {
            $mosConfig_lang = $locale;
            $languagelocale = $language->lang_code;
            
            break;
        }
    }
}

if ($languagelocale == ''){
    $mosConfig_lang = $lang->getTag();
    $languagelocale = $lang->getTag();
}

if ($languagelocale == '')
    $languagelocale = "en-GB";

// Set content language
global $langContent;
if(isset($_REQUEST['lang'])) 
    {$langContent = $_REQUEST['lang'];
}else{
    $langContent = substr($languagelocale, 0, 2);
}

if(!defined('_VEHICLE_MANAGER_LABEL_PRICE')){

    
    // load language
    $languagelocale = "";
    $query = "SELECT l.title, l.lang_code, l.sef ";
    $query .= "FROM #__vehiclemanager_const_languages as cl ";
    $query .= "LEFT JOIN #__vehiclemanager_languages AS l ON cl.fk_languagesid=l.id ";
    $query .= "LEFT JOIN #__vehiclemanager_const AS c ON cl.fk_constid=c.id ";
    $query .= "GROUP BY  l.title";
    $database->setQuery($query);
    $languages = $database->loadObjectList();

    $lang = JFactory::getLanguage();
    foreach ($lang->getLocale() as $locale) {
        foreach ($languages as $language) {
            if ($locale == $language->title || $locale == $language->lang_code || $locale == $language->sef)
            {
                $mosConfig_lang = $locale;
                $languagelocale = $language->lang_code;
                break;
            }
        }
    }
if ($languagelocale == ''){
    $mosConfig_lang = $lang->getTag();
    $languagelocale = $lang->getTag();
}
if ($languagelocale == '')
    $languagelocale = "en-GB";

    // Set content language
    global $langContent;
    $langContent = substr($languagelocale, 0, 2);


    $query = "SELECT c.const, cl.value_const ";
    $query .= "FROM #__vehiclemanager_const_languages as cl ";
    $query .= "LEFT JOIN #__vehiclemanager_languages AS l ON cl.fk_languagesid=l.id ";
    $query .= "LEFT JOIN #__vehiclemanager_const AS c ON cl.fk_constid=c.id ";
    $query .= "WHERE l.lang_code = '$languagelocale'";
    $database->setQuery($query);
    $langConst = $database->loadObjectList();

    if (version_compare(JVERSION, "1.6.0", "lt"))
    {
      jimport( 'joomla.registry.registry' );
      $config = JFactory::getConfig();
        
      $os_pass= $config->getValue( 'password' );
      $os_db = $config->getValue( 'db' );
      $os_user = $config->getValue( 'user' );
      $os_host = $config->getValue( 'host' );
      $connection = mysql_connect($os_host,$os_user,$os_pass);
        
    } else if (version_compare(JVERSION, "1.6.0", "ge") && version_compare(JVERSION, "3.5.0", "lt"))
    {
      jimport( 'joomla.registry.registry' );
      $config = JFactory::getConfig();
        
      $os_pass= $config->get( 'password' );
      $os_db = $config->get( 'db' );
      $os_user = $config->get( 'user' );
      $os_host = $config->get( 'host' );
      $connection = mysqli_connect($os_host,$os_user,$os_pass);
    }

    mysqli_select_db($connection,$os_db);

    foreach ($langConst as $item) {
        if(!defined($item->const))
            define($item->const, $item->value_const);
    }
}


if( !function_exists( 'sefreltoabs')) {
  function sefRelToAbs( $value ) {
    //Need check!!!

    // Replace all &amp; with & as the router doesn't understand &amp;
    $url = str_replace('&amp;', '&', $value);
    if(substr(strtolower($url),0,9) != "index.php") return $url;
    $uri    = JURI::getInstance();
    $prefix = $uri->toString(array('scheme', 'host', 'port'));
    return $prefix.JRoute::_($url);
  }
}

$s = vmLittleThings::getWhereUsergroupsCondition ();

//Common parameters


?>



<?php
$defaultDesigntop = $params->get('defaultDesigntop');
$body_colortop    = $params->get('body_colortop');
$displaytypetop = $params->get('displaytypetop', 1);

$sort_top_by    = $params->get('sort_by_top', 0);        //Get how to sort the top items
$show_covers     = $params->get('covers', 0 );             //Get if we Real Estate  photos
$cover_height    = $params->get('cover_height', "50");     //Get Real Estate  photos
$show_extra        = $params->get('extras', 1 );             //Get if we show second column with additional info
$show_ranking    = $params->get('ranking', 0 );             //Get if we show the ranking next to them
$showprice  = $params->get ('price', 1);
//Individual parameters
$count_vehicle= intval($params->get('books',1));
$ItemId_tmp_from_params=$params->get('ItemId'); 
$class_suffix    = $params->get('moduleclass_sfx','');
$layout = $params->get('layout', 'default');
$image_source_type = $params->get('image_source_type');


//Definition of Sorts
switch($sort_top_by) 
{
    case 0:
        $sql_sort_top = "hits";
        break;
    case 1:
        $sql_sort_top = "date";
        break;
   // case 2:
     //   $sql_sort_top = "rating";
   //     break;
}

//Check if only display published items

    $where[] = " v.published=1";
    $where[]=" c.published=1 ";
    $sql_approved = "v.approved=1 AND";
    $where[]=" ($s) ";


if($count_vehicle!='' && $count_vehicle!=0) {
    $query = "SELECT language FROM #__modules WHERE id = '$module->id'";
    $database->setQuery($query);
    $langmodule = $database->loadResult();
    
        if (isset($langContent))
        {
            $lang = $langContent;
            $query = "SELECT lang_code FROM #__languages WHERE sef = '$lang'";
            $database->setQuery($query);
            $lang = $database->loadResult();
            $lang = " and (v.language like 'all' or v.language like '' or v.language like '*' or v.language is null or v.language like '$lang')
                     AND (c.language like 'all' or c.language like '' or c.language like '*' or c.language is null or c.language like '$lang') ";
        } else
        {
            $lang = "";
        }
        
    if($langmodule != "" && $langmodule != "*"){
            $selectstring = "SELECT v.vtitle,v.id,v.image_link,v.hits,c.id AS catid,v.price, v.priceunit
                           \nFROM #__vehiclemanager_vehicles AS v
                           \nLEFT JOIN #__vehiclemanager_categories AS vc ON vc.iditem=v.id
                           \nLEFT JOIN #__vehiclemanager_main_categories AS c ON c.id=vc.idcat".
                          "\nWHERE $sql_approved".implode(" AND ",$where).$lang. "AND v.language = '$langmodule'".
                          "\nGROUP BY v.id".
                          " ORDER BY ".$sql_sort_top." DESC LIMIT 0, $count_vehicle;";
    }
    else{
             $selectstring = "SELECT v.vtitle,v.id,v.image_link,v.hits,c.id AS catid,v.price, v.priceunit
                           \nFROM #__vehiclemanager_vehicles AS v
                           \nLEFT JOIN #__vehiclemanager_categories AS vc ON vc.iditem=v.id
                           \nLEFT JOIN #__vehiclemanager_main_categories AS c ON c.id=vc.idcat".
                          "\nWHERE $sql_approved".implode(" AND ",$where).$lang.
                          "\nGROUP BY v.id".
                          " ORDER BY ".$sql_sort_top." DESC LIMIT 0, $count_vehicle;"; 
    }
                
  $database->setQuery($selectstring);
  $rows_vehicle= $database->loadObjectList();
}
$database->setQuery("SELECT id FROM #__menu WHERE link LIKE'%option=com_vehiclemanager%' AND params LIKE '%back_button%'");
$ItemId_tmp_from_db = $database->loadResult();
if($ItemId_tmp_from_params!=''){
      $ItemId_tmp=$ItemId_tmp_from_params;
    }
    else{
      $ItemId_tmp=$ItemId_tmp_from_db;
    }
if (!function_exists('picture_thumbnail')){
    function picture_thumbnail($file, $high_original, $width_original) {
        

        // get name and type
        $file_inf = pathinfo($file);
        $tmp_type = explode(".", $file_inf['basename']);
        $file_type = "." . end($tmp_type);
        $file_name = basename($file_inf['basename'], $file_type);
        
        // Setting the resize parameters
        list($width, $height) = getimagesize('./components/com_vehiclemanager/photos/' . $file);

        $size = "_" . $high_original . "_" . $width_original;

        if (file_exists('./components/com_vehiclemanager/photos/' . $file_name . $size . $file_type)) {
            return $file_name . $size . $file_type;
        } else {
            if ($width < $height) {
                if ($height > $high_original) {
                    $k = $height / $high_original;
                } else if ($width > $width_original) {
                    $k = $width / $width_original;
                }
                else
                    $k = 1;
            } else {
                if ($width > $width_original) {
                    $k = $width / $width_original;
                } else if ($height > $high_original) {
                    $k = $height / $high_original;
                }
                else
                    $k = 1;
            }
            $w_ = $width / $k;
            $h_ = $height / $k;
        }

        // Creating the Canvas
        $tn = imagecreatetruecolor($w_, $h_);

        switch (strtolower($file_type)) {
            case '.png':
                $source = imagecreatefrompng('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagepng($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            case '.jpg':
                $source = imagecreatefromjpeg('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagejpeg($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            case '.jpeg':
                $source = imagecreatefromjpeg('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagejpeg($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);

                break;
            case '.gif':
                $source = imagecreatefromgif('./components/com_vehiclemanager/photos/' . $file);
                $file = imagecopyresampled($tn, $source, 0, 0, 0, 0, $w_, $h_, $width, $height);
                imagegif($tn, './components/com_vehiclemanager/photos/' . $file_name . $size . $file_type);
                break;
            default:
                echo 'not support';
                return;
        }

        return $file_name . $size . $file_type;
    }
}

if( !function_exists( 'DisplayVM')) {
    
    
    function DisplayVM($rows, $name, $show_ranking, $show_covers, $show_extra, $cover_height, $ItemId_tmp,$showprice, $class_suffix,
      $defaultDesigntop, $body_colortop, $displaytypetop, $layout, $image_source_type) {
        global $vehiclemanager_configuration;
        $rank_count = 0;
        $span=0;
        if($show_ranking!=0) $span++;
        if($show_covers!=0) $span++;
        if($show_extra!=0) $span++;
    if ($defaultDesigntop == 1) {
    ?>
    <style type="text/css">

    .vehiclemanager_ {
        overflow: hidden;
    }

    .block_list_in {
        margin: 10px;
        padding: 10px;
        overflow: hidden;
        border: 1px solid #D6D6D6;
        /* width:200px;
        height: 250px;*/
    }

    .block_list_in a {}

    .block_list_img {
        text-align: center;
        margin-bottom: 10px;
    }

    .block_list_in img {}
    .block_list_model {}
    .priceAndHits {}
    .block_list_price {}
    .block_list_hits {}
    </style>
    <?php } ?>   

    <div class="vehiclemanager_ <?php if($class_suffix !='') echo $class_suffix ;?>">
    <?php 
    if (version_compare(JVERSION, "3.0.0", "lt"))
        require(JModuleHelper::getLayoutPath('mod_vehiclemanager_top_pro', $layout)); else
        require (JModuleHelper::getLayoutPath('mod_vehiclemanager_top_pro_j3',$layout ));	
    ?>  
    <?php
    }   
}
?>

   
<?php 
if(count($rows_vehicle)) {DisplayVM($rows_vehicle, "Top  Vehicles", $show_ranking, $show_covers, $show_extra,$cover_height, $ItemId_tmp,
  $showprice, $class_suffix, $defaultDesigntop, $body_colortop, $displaytypetop,$layout, $image_source_type); }
   
?>
  
</div>
