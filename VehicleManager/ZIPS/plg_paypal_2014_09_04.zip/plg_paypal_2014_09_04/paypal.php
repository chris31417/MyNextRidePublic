<?php
/**
 * 
 * @package simpleMembership
 * @copyright Andrey Kvasnevskiy-OrdaSoft(akbet@mail.ru); 
 * Homepage: http://www.ordasoft.com
 * @version: 1.0 PRO
 *
 *
 */
defined ('_JEXEC') or die ("Go away.");
defined( 'DS' ) or define( 'DS', DIRECTORY_SEPARATOR);

jimport( 'joomla.plugin.plugin' );

require_once(dirname(__FILE__).DS.'paypal'.DS.'helper.php');

class  plgPaymentPaypal extends JPlugin
{
	public $responseStatus = array (
				'Completed' 		=> 'C',
				'Pending' 			=> 'P',
				'Failed' 			=> 'E',
				'Denied' 			=> 'D',
				'Refunded'			=> 'RF',
				'Canceled_Reversal' => 'CRV',
				'Reversed'			=> 'RV'
			);
	function __construct($subject, $config)
	{
		parent::__construct($subject, $config);
		//Set the language in the class
		//$config = JFactory::getConfig();

		//Define Payment Status codes in Paypal  And Respective Alias in Framework
		$this->responseStatus= array (
				'Completed' 		=> 'C',
				'Pending' 			=> 'P',
				'Failed' 			=> 'E',
				'Denied' 			=> 'D',
				'Refunded'			=> 'RF',
				'Canceled_Reversal' => 'CRV',
				'Reversed'			=> 'RV'
			);
	}
	function validateIPN() {
		$params 		= $this->params;
        $paypal_real_or_test  =  $params->get('paypal_real_or_test');
        $receiver_email  =  $params->get('paypal_email');
        $currency_code  =  array('AUD','CAD','CZK','DKK','EUR','HKD','HUF','JPY','NOK','NZD','PLN','SGD','SEK','CHF','USD','RUB');
        return plgPaymentPaypalHelper::validateIPN($paypal_real_or_test,$receiver_email,$currency_code);
	}

	/* Internal use functions */
	function buildLayoutPath($layout) {
		jimport('joomla.filesystem.file');
		$app = JFactory::getApplication();
		$core_file 	= dirname(__FILE__).DS.$this->_name.DS.'tmpl'.DS.$layout.'.php';
		$override		= JPATH_BASE.DS.'templates'.DS.$app->getTemplate().DS.'html'.DS.'plugins'.DS.$this->_type.DS.$this->_name.DS.$layout.'.php';
		if(JFile::exists($override))
		{
			return $override;
		}
		else
		{
	  	return  $core_file;
	}
	}

	//Builds the layout to be shown, along with hidden fields.
	function buildLayout($vars, $layout = 'default' )
	{
		// Load the layout & push variables
		ob_start();
		$layout = $this->buildLayoutPath($layout);
		include($layout);
		$html = ob_get_contents(); 
		ob_end_clean();
		return $html;
	}

	// Used to Build List of Payment Gateway in the respective Components
	function onTP_GetInfo($config)
	{

		if(!in_array($this->_name,$config))
		return;
		$obj 		= new stdClass;
		$obj->name 	=$this->params->get( 'plugin_name' );
		$obj->id	= $this->_name;
		return $obj;
	}

	//Constructs the Payment form in case of On Site Payment gateways like Auth.net & constructs the Submit button in case of offsite ones like Paypal
	function getHTMLPayPal($varss, $data = null, $req = null) {
		global $mosConfig_absolute_path, $user_configuration;
        $vars['item_number'] = '';
        $components = $_REQUEST['option'];
        $vars['return_url']   =  JUri::base().'index.php?option='.$components.'&view=paypal&operation=success&';
        $vars['cancel_url']   =  JUri::base().'index.php?option='.$components.'&view=paypal&operation=cancel&';
        $vars['notify_url']   =  JUri::base().'index.php?option='.$components.'&view=paypal&operation=notify&';
        


        if($components == 'com_simplemembership') {
            $orderid = $_REQUEST['userId']['OrderID'];
            $vars['item_number'] =  $orderid;
            $vars['return_url']   .=  'orderid='.$orderid;
            $vars['cancel_url']   .=  'orderid='.$orderid;
            $vars['notify_url']   .=  'orderid='.$orderid;
            
        }elseif($components == 'com_vehiclemanager') {
            if(isset($_REQUEST['id'])) {
                $vehicleId = $_REQUEST['id'];
                $vehicle_bayer = $_REQUEST['name_bayer'];
                if($_REQUEST['userId'] == '') {
                    $userId = 0;
                } else {$userId = $_REQUEST['userId'];}
                $vars['item_number'] = $_REQUEST['orderID'];
            }
            $vars['return_url']   .= 'vehicle='.$vehicleId.'&userId='.$userId;
            $vars['cancel_url']   .= 'vehicle='.$vehicleId.'&userId='.$userId;
            $vars['notify_url']   .= 'vehicle='.$vehicleId.'&userId='.$userId;
            
        }elseif($components == 'com_realestatemanager') {
        	if(isset($_REQUEST['id'])) {
                $houseId = $_REQUEST['id'];
                $vehicle_bayer = $_REQUEST['name_bayer'];
                if($_REQUEST['userId'] == '') {
                    $userId = 0;
                } else {$userId = $_REQUEST['userId'];}
                $vars['item_number'] = $_REQUEST['orderID'];
            }
            $vars['return_url'] .=  'vehicle='.$houseId.'&userId='.$userId;
            $vars['cancel_url'] .= 'vehicle='.$houseId.'&userId='.$userId;
            $vars['notify_url'] .= 'vehicle='.$houseId.'&userId='.$userId;
        }


        $params = $this->params;
        $vars['paypal_email'] =  $params->get('paypal_email');
        $vars['image_url']    =  $params->get('image_url');
        $vars['item_name']    =  $varss['vtitle'];
        $vars['price']        =  $varss['price'];
	$vars['currency_code']  =  $varss['currency_code'];
	
/*components/com_realestatemanager/functions.php:1050:
function getHTMLPayPal($vehicle,$plugin_name_select)*/

        $paypal_real_or_test  =  $params->get('paypal_real_or_test');


		
        if($paypal_real_or_test == 0) {
        	$vars['paypal_path'] = 'www.sandbox.paypal.com';
        } else {
        	$vars['paypal_path'] = 'www.paypal.com';
        }
        $html = $this->buildLayout($vars);
        return $html;
	}



// 	function onTP_Processpayment($data) 
// 	{		
// 		$params 		= $this->params;
// 		$secure_post 	= $params->get('secure_post');
// 		$sandbox 		= $params->get('sandbox');
// 		$paypal_url 	= plgPaymentPaypalHelper::buildPaypalUrl($secure_post , $sandbox);
// 
// 		$verify 		= plgPaymentPaypalHelper::validateIPN($data);
// 
// 		if (!$verify) { return false; }
// 		$payment_status = $this->translateResponse( $data['payment_status'] );
// 		$result = array(
// 						'order_id'=>$data['custom'],
// 						'transaction_id'=>$data['txn_id'],
// 						'buyer_email'=>$data['payer_email'],
// 						'status'=>$payment_status,
// 						'subscribe_id'=>$data['subscr_id'],
// 						'txn_type'=>$data['txn_type'],
// 						'total_paid_amt'=>$data['mc_gross'],
// 						'raw_data'=>$data,
// 						'error'=>$error,
// 						);
// 		return $result;
// 	}

// 	function translateResponse($payment_status){
// 			if(array_key_exists($payment_status,$this->responseStatus)){
// 				return $this->responseStatus[$payment_status];
// 			}
// 	}
// 	function onTP_Storelog($data)
// 	{
// 			$log = plgPaymentPaypalHelper::Storelog($this->_name,$data);
// 
// 	}
}
