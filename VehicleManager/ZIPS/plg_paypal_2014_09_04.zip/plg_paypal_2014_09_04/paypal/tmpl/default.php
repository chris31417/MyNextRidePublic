<?php
/**
 * 
 * @package simpleMembership
 * @copyright Andrey Kvasnevskiy-OrdaSoft(akbet@mail.ru);
 * Homepage: http://www.ordasoft.com
 * @version: 1.0 PRO
 *
 *
 */
defined('_JEXEC') or die('Restricted access');

?>


<div class="akeeba-bootstrap">
<form action="https://<?php echo $vars['paypal_path']
."/en/cgi-bin/webscr"; ?>" class="form-horizontal" method="post" target="paypal">
<input type="hidden" name="cmd" value="_xclick" />
<input type="hidden" name="business" value="<?php echo $vars['paypal_email']; ?>" />
<!--<input type="hidden" name="undefined_quantity" value="0" />-->
<input type="hidden" name="item_name" value="<?php echo $vars['item_name']; ?>" />
<!--input type="hidden" name="mc_gross" value="<?php echo $vars['price']; ?>" /-->
<input type="hidden" name="amount" value="<?php echo $vars['price']; ?>" />
<input type="hidden" name="notify_url" value="<?php echo $vars['notify_url'];  ?>" />
<input type="hidden" name="return" value="<?php echo $vars['return_url']; ?>" />
<input type="hidden" name="cancel_return" value="<?php echo $vars['cancel_url']; ?>" />
<input type="hidden" name="currency_code" value="<?php echo $vars['currency_code']; ?>" />
<input type="hidden" name="rm" value="2" />
<input type="hidden" name="item_number" value="<?php echo $vars['item_number']; ?>" />
<input type="hidden" name="custom" value="" />
<!--input type="hidden" name="charset" value="utf-8" /-->
<input type="hidden" name="no_shipping" value="1" />
<input type="hidden" name="image_url" value="<?php echo $vars['image_url']; ?>" />
<input type="hidden" name="no_note" value="0" />
<input id="paypal" type="submit" name="submit" alt="PayPal secure payments." value="Buy now" />

</form>
</div>
