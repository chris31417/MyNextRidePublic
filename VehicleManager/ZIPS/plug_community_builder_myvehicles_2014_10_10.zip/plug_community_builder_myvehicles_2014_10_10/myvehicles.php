<?php
/** ensure this file is being included by a parent file */
defined('_JEXEC') or die( 'Direct Access to this location is not allowed.' );
$mosConfig_absolute_path = $GLOBALS['mosConfig_absolute_path']  = JPATH_SITE;
require_once ($mosConfig_absolute_path."/components/com_vehiclemanager/vehiclemanager.class.php");
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_comprofiler/plugin/user/plug_myvehicles/buttons.css');
//$document->addScript(JURI::root(true).'/components/com_vehiclemanager/lightbox/js/jQuerREL-1.2.6.js');
$document->addScript(JURI::root(true).'/components/com_vehiclemanager/includes/functions.js');
if(!array_key_exists('vehiclemanager_configuration', $GLOBALS)){ 
    require_once ($mosConfig_absolute_path."/administrator/components/com_vehiclemanager/admin.vehiclemanager.class.conf.php");
    $GLOBALS['vehiclemanager_configuration'] = $vehiclemanager_configuration;
}
// load language
$lang_def_en=0;
$lang = JFactory::getLanguage();
foreach ($lang->getLocale() as $locale){
    $mosConfig_lang=$locale;
    if (file_exists($mosConfig_absolute_path."/components/com_vehiclemanager/lang/{$mosConfig_lang}.php")){
        include_once($mosConfig_absolute_path."/components/com_vehiclemanager/lang/{$mosConfig_lang}.php");
        $lang_def_en=1;
        break;
    }
}
if ( $lang_def_en != 1 ){
   $mosConfig_lang = "english";  
   include_once($mosConfig_absolute_path."/components/com_vehiclemanager/lang/English.php");
}

class getmyvehiclesTab extends cbTabHandler {
    /**
     * Constructor
     */
    function getmyvehiclesTab(){
        $this->cbTabHandler();
    }


   /* function getDisplayTab($tab,$user,$ui){
        $return = null;
        if($tab->description!=null){
            $return.= "<div class=\"tab_Description\">" . $tab->description."</div>";
        }
        $return.=$this->getVehiclesView($user->name);
        return $return;
    } // end or getDisplayTab function*/
    
    function userGID_Veh1($oID){
        $database = JFactory::getDBO();
        $group_id = array ();
        if($oID > 0){
            $query = "SELECT `group_id` FROM `#__user_usergroup_map` WHERE `user_id` = $oID";
            $database->setQuery($query);
            $rows = $database->loadObjectList();
            foreach ($rows as $k => $v) $group_id[] = $rows[$k]->group_id;
        } else $group_id[] = -2; // for Everyone (user:anonymous)
        return $group_id;
    }

    function checkAccess_Veh1( $accessgroupid, $recurse, $usersgroupid, $acl){
        if (!is_array($usersgroupid)){
            $usersgroupid = $usersgroupid * 1;
            if (!(is_int($usersgroupid))) return false;
                else{
                    if (is_int($usersgroupid) AND isset($usersgroupid) AND $usersgroupid > 0){
                        $t = $usersgroupid;
                        $usersgroupid = (array) $usersgroupid; // force to array
                        $usersgroupid[] = $t;
                    } elseif (is_int($usersgroupid) AND isset($usersgroupid) AND $usersgroupid == 0 ){
                        $usersgroupid = (array) $usersgroupid; // force to array
                        $usersgroupid[] = 0;
                    }
                }
        }

        $tempArr = array();
        $tempArr = explode(',' , $accessgroupid);

        for($i = 0;$i<count($tempArr);$i++){
            if(($tempArr[$i] == $usersgroupid OR in_array($tempArr[$i],$usersgroupid)) || $tempArr[$i]==-2) return true;
                else{
                    if($recurse == 'RECURSE'){
                        if (is_array($usersgroupid)){
                            for ($j=0; $j<count($usersgroupid); $j++){
                                if(in_array($usersgroupid[$j], $tempArr)) return 1;
                            }
                        } else if (in_array($usersgroupid, $tempArr)) return 1;
                    }
                }
        } 

        return 0;
    } 

    function getDisplayTab($tab,$user,$ui){
        global $mosConfig_absolute_path, $vehiclemanager_configuration;
        $my = JFactory::getUser();
        $acl = JFactory::getACL();
        $viewer = JFactory::getUser();
        $document = JFactory::getDocument();
        $return = null;
        $params = $this->params; // get parameters (plugin and related tab)
        $db = JFactory::getDBO();
        if($tab->description != null) {
            $return.= "<div class=\"tab_Description\">" . $tab->description. "</div>";
        }

        $usermail=$user->email;
        if(isset($_GET['user'])) $userid=$_GET['user']; else $userid=$viewer->id;
        $query = "SELECT u.id, u.name AS username FROM #__users AS u WHERE u.id = '$userid';";
        $db->setQuery($query);
        $ownerslist = $db->loadObjectList();
        foreach($ownerslist as $owner) $owner->username;
        $username= $owner->username;
        $viewerid=$viewer->id;

        $query ="SELECT * FROM #__vehiclemanager_vehicles AS h".
                " LEFT JOIN #__vehiclemanager_rent_request AS r ON h.id=r.fk_vehicleid".
                " WHERE r.status=0 AND  h.owneremail = '$usermail' AND h.id = r.fk_vehicleid;";
        $db->setQuery($query);
        $ownervehicle = $db->loadObjectList();
        foreach($ownervehicle as $vowner) $vowner->owneremail;
        if(isset($vowner->owneremail)==$usermail) $vehicleowner=$vowner->owneremail;

        $query ="SELECT * FROM #__vehiclemanager_vehicles AS h".
                " LEFT JOIN  #__vehiclemanager_buying_request AS br ON h.id=br.fk_vehicleid".
                " WHERE  h.owneremail = '$usermail' AND h.id = br.fk_vehicleid;";
        $db->setQuery($query);  
        $ownerbuyvehicle = $db->loadObjectList();
        foreach($ownerbuyvehicle as $buyowner) $buyowner->owneremail;
        if(isset($buyowner->owneremail)==$usermail) $buyvehicleowner=$buyowner->owneremail;

        $query="SELECT * FROM #__vehiclemanager_rent AS r WHERE r.fk_userid = '$viewerid' OR r.user_email = '$usermail'";
        $db->setQuery($query);
        $current_user_rent_history_array = $db->loadObjectList();
        $check_for_show_rent_history=0;
        if(isset($current_user_rent_history_array)){
            foreach($current_user_rent_history_array as $temp)
                if($temp->fk_userid == $viewerid) $check_for_show_rent_history=1;
        }

        $query="SELECT * FROM #__vehiclemanager_rent_request AS v WHERE v.status=0";
        $db->setQuery($query);
        $current_user_rent_request_array = $db->loadObjectList();
        $check_for_show_rent_request=0;
        if(isset($current_user_rent_request_array))
            foreach( $current_user_rent_request_array as $temp) $check_for_show_rent_request=1;

        if(($vehiclemanager_configuration['cb_myvehicle']['show'])){
            $params->def('show_cb', 1);
            $i=getmyvehiclesTab::checkAccess_Veh1($vehiclemanager_configuration['cb_myvehicle']['registrationlevel'],'NORECURSE', getmyvehiclesTab::userGID_Veh1($my->id), $acl);
            if($i) $params->def('show_cb_registrationlevel', 1);
        }

        if(($vehiclemanager_configuration['cb_edit']['show'])){
            $params->def('show_edit', 1);
            $i=getmyvehiclesTab::checkAccess_Veh1($vehiclemanager_configuration['cb_edit']['registrationlevel'],'NORECURSE', getmyvehiclesTab::userGID_Veh1($my->id), $acl);
            if($i) $params->def('show_edit_registrationlevel', 1);
        }

        if(($vehiclemanager_configuration['cb_rent']['show'])){
            $params->def('show_rent', 1);
            $i=getmyvehiclesTab::checkAccess_Veh1($vehiclemanager_configuration['cb_rent']['registrationlevel'],'NORECURSE', getmyvehiclesTab::userGID_Veh1($my->id), $acl);
            if($i) $params->def('show_rent_registrationlevel', 1);
        }

        if(($vehiclemanager_configuration['cb_buy']['show'])){
            $params->def('show_buy', 1);
            $i=getmyvehiclesTab::checkAccess_Veh1($vehiclemanager_configuration['cb_buy']['registrationlevel'],'NORECURSE', getmyvehiclesTab::userGID_Veh1($my->id), $acl);
            if($i) $params->def('show_buy_registrationlevel', 1);
            $params->get('show_buy');
        }

        if(($vehiclemanager_configuration['cb_history']['show'])){
            $params->def('show_history', 1);
            $i=getmyvehiclesTab::checkAccess_Veh1($vehiclemanager_configuration['cb_history']['registrationlevel'],'NORECURSE', getmyvehiclesTab::userGID_Veh1($my->id), $acl);
            if($i) $params->def('show_history_registrationlevel', 1);
        }

        if($viewerid==$userid){
            if($params->get('show_cb')){
                if($params->get('show_cb_registrationlevel')){
                    $return .= "<div class='button_margin'>" ;
                    $return .= " <span class='vehicle_button'><a href='".JRoute::_('index.php?option=com_comprofiler&task=my_vehicles&tab=getmyvehiclesTab&name='.$username.'&user='.$userid.'&is_show_data=1') . "'>" . JText::_('show vehicles') ."</a></span>" ;
                }
            }

            if($params->get('show_edit')){
                if($params->get('show_edit_registrationlevel')){
                    $return .= " <span class='edit_button'><a href='".JRoute::_('index.php?option=com_comprofiler&task=edit_my_cars&tab=getmyvehiclesTab&is_show_data=1') . "'>" . JText::_('edit vehicles') ."</a></span>" ;
                }
            }

            if($usermail==isset($vehicleowner)){
                if($check_for_show_rent_request!=0){
                    if($params->get('show_rent')){
                        if($params->get('show_rent_registrationlevel')){
                            $return .= " <span class='edit_button'><a href='".JRoute::_('index.php?option=com_comprofiler&task=rent_requests_vehicle&tab=getmyvehiclesTab&is_show_data=1') . "'>" . JText::_('rent requests') ."</a></span>";
                        }
                    }
                }
            }

            if($usermail==isset($buyvehicleowner)){
                if($params->get('show_buy')){
                    if($params->get('show_buy_registrationlevel')){
                        $return .= " <span class='edit_button'><a href='".JRoute::_('index.php?option=com_comprofiler&task=buying_requests_vehicle&tab=getmyvehiclesTab&is_show_data=1') . "'>" . JText::_('buying  requests') ."</a></span>" ;
                    }
                }
            }

            if($check_for_show_rent_history!=0){
                if($params->get('show_history')){
                    if($params->get('show_history_registrationlevel')){
                        $return .= " <span class='vehicle_button'><a href='".JRoute::_('index.php?option=com_comprofiler&task=rent_history_vehicle&tab=getmyvehiclesTab&name='.$username.'&user='.$userid.'&is_show_data=1') . "'>" . JText::_('my rent history') ."</a></span>" ;
                    }
                }
            }

            $return .= "</div>";
            $return .= $this->getVehiclesView($username);
        } else{
            header('location: '.$mosConfig_live_site.'/index.php?option=com_comprofiler&task=my_vehicles&tab=getmyvehiclesTab&name='.$username.'&user='.$userid);
            $return .= $this->getVehiclesView($username);
        }
        
        return $return;
    } // end or getDisplayTab function

    function getVehiclesView($username){
        global $option;
        if(!defined('DS'))
        define('DS', DIRECTORY_SEPARATOR);
        $path = JPATH_SITE.DS.'components'.DS.'com_vehiclemanager'.DS.'vehiclemanager.php';
        if (!function_exists('showMyCars')){
            $false = false;
            if (file_exists($path)){
                ob_start();
                if (isset($_REQUEST['task'])) $task=$_REQUEST['task'];
                    else {
                        $_SESSION['vm_user'] = $username;
                        $_GLOBALS['task'] = $task = "view_user_vehicles";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                    }
                switch ($task){ 
                    case 'show_my_cars':
                        $_GLOBALS['task'] = $task = "my_vehicles";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'edit_my_cars':
                        $_GLOBALS['task'] = $task = "edit_my_cars";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'my_vehicles':
                        $_GLOBALS['task'] = $task = "my_vehicles";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'show_add_vehicle':
                        $_GLOBALS['task'] = $task = "show_add_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'save_add_vehicle':
                        $_GLOBALS['task'] = $task = "save_add_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'edit_vehicle':
                        $_GLOBALS['task'] = $task = "edit_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'view_vehicle':
                        $_GLOBALS['task'] = $task = "view_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'rent_vehicle':
                        $_GLOBALS['task'] = $task = "rent_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'rent_return_vehicle':
                        $_GLOBALS['task'] = $task = "rent_return_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'rent_history_vehicle':
                        $_GLOBALS['task'] = $task = "rent_history_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'rent_request_vehicle':
                        $_GLOBALS['task'] = $task = "rent_request_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'save_rent_request_vehicle':
                        $_GLOBALS['task'] = $task = "save_rent_request_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'buying_request_vehicle':
                        $_GLOBALS['task'] = $task = "buying_request_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'rent_requests_vehicle':
                        $_GLOBALS['task'] = $task = "rent_requests_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'accept_rent_requests_vehicle':
                        $_GLOBALS['task'] = $task = "accept_rent_requests_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'decline_rent_requests_vehicle':
                        $_GLOBALS['task'] = $task = "decline_rent_requests_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'buying_requests_vehicle':
                        $_GLOBALS['task'] = $task = "buying_requests_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'accept_buying_requests_vehicle':
                        $_GLOBALS['task'] = $task = "accept_buying_requests_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'decline_buying_requests_vehicle':
                        $_GLOBALS['task'] = $task = "decline_buying_requests_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'publish_vehicle':
                        $_GLOBALS['task'] = $task = "publish_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'unpublish_vehicle':
                        $_GLOBALS['task'] = $task = "unpublish_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'delete_vehicle':
                        $_GLOBALS['task'] = $task = "delete_vehicle";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'review_veh':
                        $_GLOBALS['task'] = $task = "review_veh";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                        break;
                    case 'ajax_rent_calcualete': 
                        $_GLOBALS['task'] = $task = "ajax_rent_calcualete";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                    default:
                        $_GLOBALS['task'] = $task = "my_vehicles";
                        $_GLOBALS['option'] = $option = "com_comprofiler";
                    ?>
                        <script>
                            jQuerREL('.tab').ready(function() {
                                jQuerREL('.tab').mouseup(function() {
                                    setTimeout('vm_initialize2()',10);
                                });
                            });
                        </script>
                    <?php
                        break;
                }
                require_once($path);
                $view = ob_get_contents();
                ob_end_clean();
                return $view;
                if (!function_exists('showMyCars')){
                    JError::raiseWarning( 0, 'View class showMyCars not found in file.' );
                    return $false;
                }
            } else{
                JError::raiseWarning( 0, 'View showMyCars not supported. File not found.' );
                return $false;
            }
            return $view;
        }
    }
} // end of getmyvehiclesTab class
?>
