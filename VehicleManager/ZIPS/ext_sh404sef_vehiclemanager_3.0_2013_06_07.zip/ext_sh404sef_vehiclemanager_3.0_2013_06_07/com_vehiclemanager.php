<?php
/**
 * sh404SEF support for com_realestatemanager component.
 * Author : Sergey Drughinin sergey.dru@gmail.com
 * 
 * Version 1.6
 * Joomla 1.5.11 and sh404SEF 1.0.7
 * copyright (C) 2010 OrdaSoft
 * This is a sh404SEF native plugin file
 
        [Installation]:
    [1] create folder /components/com_vehiclemanager/sef_ext
    [2] copy  com_vehiclemanager.php into the one
    [3] install  sh404SEF component
    [4] Go to BackEnd->Components->sh404SEF->ControlPanel->Configuration->sh404SEF_Configuration->ByComponent
    [5] Set Vehicle Manager to [Use sh404SEF plugin if available] 
 *    
 */

if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' );
if (!defined('DS')) define('DS', DIRECTORY_SEPARATOR);
require_once ( JPATH_BASE .DS.'components'.DS.'com_vehiclemanager'.DS.'functions.php' );


// ------------------  standard plugin initialize function - don't change ---------------------------
$shLangName = '';
$shLangIso = '';
$title = array();
$shItemidString = '';
$dosef = shInitializePlugin( $lang, $shLangName, $shLangIso, $option);
// ------------------  standard plugin initialize function - don't change ---------------------------

// $database is directly needed by some functions, so we need to create it here. 
$GLOBALS['database'] = $database = JFactory::getDBO();
global $database;

// remove common URL from GET vars list, so that they don't show up as query string in the URL
shRemoveFromGETVarsList('option');
shRemoveFromGETVarsList('lang');
if (!empty($Itemid))
  shRemoveFromGETVarsList('Itemid');
if (!empty($limit))  
shRemoveFromGETVarsList('limit');
if (isset($limitstart)) 
  shRemoveFromGETVarsList('limitstart'); // limitstart can be zero

if($option=='com_vehiclemanager') { 
  $title[] = 'VehicleManager';
  if ( (!isset($task) OR $task == '' ) AND  isset($view)  ) $task = $view;
  
  
  if(isset($task)) {
    switch($task) {
      case 'show_search':
        $title[] = 'ShowSearch';
	    break;
	  case 'search':
	    $title[] = 'Search';
	    break;
	  case 'view':
	    //$title[] = 'View';
	    shRemoveFromGETVarsList($task);
	    break;
    case 'alone_category':  
	  case 'showCategory':
	    //$title[] = "showCategory"; 
	    shRemoveFromGETVarsList($task);
      break;
	  case 'review':
	    $title[] = 'Review';
	    break;
      default:
        $title[] = $task;
        break;
    }

    shRemoveFromGETVarsList('task');
    shRemoveFromGETVarsList('layout');
    shRemoveFromGETVarsList('view');
    shRemoveFromGETVarsList('letindex');
    shRemoveFromGETVarsList('name');
  }

    $s = vmLittleThings::getWhereUsergroupsCondition ();
    
  //To get name of category
 
  if(isset($catid)) {
    	if($catid>0) {
        $query = "SELECT  c.name, c.id AS catid, c.parent_id
                  FROM #__vehiclemanager_main_categories AS c
                  WHERE ($s) AND c.id = ".intval($catid);
                  
          // Another working variant   
            /*   $query = "SELECT c.id, c.name, vc.idcat, c.parent_id 
                       FROM #__vehiclemanager_main_categories AS c"
          . "\n LEFT JOIN #__vehiclemanager_categories AS vc ON vc.idcat=c.id"
	        . "\n LEFT JOIN #__vehiclemanager_vehicles AS a ON vc.iditem=a.id "
          . " WHERE ({$s})  AND c.id = ".intval($catid);        */
            
               
        $database->setQuery($query);
        $row = null;
        $row = $database->loadObject();
        
        if(isset($row)) {
          $cattitle = array();
          $cattitle[] = $row->name;
          shRemoveFromGETVarsList('catid');
       

          while(isset($row) && $row->parent_id>0) {
            $query = "SELECT  name, c.id AS catid, parent_id 
                      FROM #__vehiclemanager_main_categories AS c
                      WHERE ($s) AND c.id = ".intval($row->parent_id);
          
            $database->setQuery($query);
            $row = $database->loadObject();
            if(isset($row) && $row->name!=''){
              $cattitle[] = $row->name;
            }
          }
          $title = array_merge($title,array_reverse($cattitle));
         
       
        }
      } else {
            shRemoveFromGETVarsList('catid');
      }
  }

// get Vehicles title

  if(isset($id)) {

              
    $query = "SELECT v.vtitle, c.id AS catid 
              FROM #__vehiclemanager_vehicles AS v
              LEFT JOIN #__vehiclemanager_categories AS vc ON v.id=vc.iditem
	            LEFT JOIN #__vehiclemanager_main_categories AS c ON c.id=vc.idcat 
              WHERE ({$s}) AND v.id=".intval($id)."
              GROUP BY v.id";  
         
    $database->setQuery($query);
    $row = null;
    $row = $database->loadObject();
    if(isset($row)) {
      $title[]=$row->vtitle;
      shRemoveFromGETVarsList('id');
    }
  }
}
if(isset($Itemid)) {
      shRemoveFromGETVarsList('Itemid');
}

// ------------------  standard plugin finalize function - don't change ---------------------------  
if ($dosef){
   $string = shFinalizePlugin( $string, $title, $shAppendString, $shItemidString, 
      (isset($limit) ? @$limit : null), (isset($limitstart) ? @$limitstart : null), 
      (isset($shLangName) ? @$shLangName : null));
}      
// ----------------  standard plugin finalize function - don't change ---------------------------

?>
