<?php
/*
 * @package OS_Touch_Slider
 * @subpackage  mod_vehicle_OS_TouchSlider
 * @copyright Andrey Kvasnevskiy-OrdaSoft(akbet@mail.ru); Sergey Bunyaev(sergey@bunyaev.ru); Sergey Solovyev(solovyev@solovyev.in.ua)
 * @Homepage: http://www.ordasoft.com
 * @version: 1.0 
 * @license GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
require_once dirname(__FILE__).'/helpers/images.php';
require_once dirname(__FILE__).'/helpers/helper.php';

global $vehiclemanager_configuration;

$database = JFactory::getDbo();

// load language
$languagelocale = "";
$query = "SELECT l.title, l.lang_code, l.sef ";
$query .= "FROM #__vehiclemanager_const_languages as cl ";
$query .= "LEFT JOIN #__vehiclemanager_languages AS l ON cl.fk_languagesid=l.id ";
$query .= "LEFT JOIN #__vehiclemanager_const AS c ON cl.fk_constid=c.id ";
$query .= "GROUP BY  l.title";
$database->setQuery($query);
$languages = $database->loadObjectList();

$lang = JFactory::getLanguage();
foreach ($lang->getLocale() as $locale) {
    foreach ($languages as $language) {
        if ($locale == $language->title || $locale == $language->lang_code || $locale == $language->sef)
        {
            $mosConfig_lang = $locale;
            $languagelocale = $language->lang_code;
            break;
        }
    }
}
if ($languagelocale == ''){
    $mosConfig_lang = $lang->getTag();
    $languagelocale = $lang->getTag();
}

if ($languagelocale == '')
    $languagelocale = "en-GB";

// Set content language
$langContent = substr($languagelocale, 0, 2);
global $langContent;

$show_type =$params->get('type','horizontal');
JHtml::_('stylesheet',JURI::base()."/modules/mod_vehicle_OS_TouchSlider/assets/css/idangerous-swiper.css");
if($params->get('jquery-local',1) == "1" && $params->get('jquery',1) == "1") {
    JHtml::_('script',JURI::base()."/modules/mod_vehicle_OS_TouchSlider/assets/js/jquery-1.7.1.min.js");
} elseif ($params->get('jquery',1) == "1") {
    JHtml::_('script','//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js');
}
if($params->get('no-conflict',0) == '1') {
    $doc =JFactory::getDocument();
    $doc->addScriptDeclaration("jQuery.noConflict();");
}
if(!is_numeric($width = $params->get('width'))) $width = 240;
if(!is_numeric($height = $params->get('height'))) $height = 180;

JHtml::_('script',JURI::base()."/modules/mod_vehicle_OS_TouchSlider/assets/js/idangerous-swiper.js");
$arrows = $params->get('arrows','1');
$respect_quite = $params->get('respect_quite','1');
$dots = $params->get('dots','1');
$autoplay = $params->get('autoplay','1');
$sufix = $params->get('sufix',''); 
require JModuleHelper::getLayoutPath('mod_vehicle_OS_TouchSlider', $params->get('layout', 'default'));