DROP TABLE IF EXISTS `#__carshopping_survey`;
DROP TABLE IF EXISTS `#__carshopping_shoppingprofile`;
DROP TABLE IF EXISTS `#__carshopping_dilemma`;
DROP TABLE IF EXISTS `#__carshopping_dilemma_choices`;
DROP TABLE IF EXISTS `#__carshopping_brand`;
DROP TABLE IF EXISTS `#__carshopping_city`;
DROP TABLE IF EXISTS `#__carshopping_product_advisor_profile`;
DROP TABLE IF EXISTS `#__carshopping_dealer_profile`;
DROP TABLE IF EXISTS `#__carshopping_product_advisors_brand`;
DROP TABLE IF EXISTS `#__carshopping_matches`;
DROP TABLE IF EXISTS `#__carshopping_matches_messages`;


