<?php

/**
 * @version     1.0.0
 * @package     com_carshopping
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      aldo <aldopraherda@gmail.com> - http://www.aldoapp.com
 */
defined('_JEXEC') or die;


/**
 * 
 */
class CarshoppingModelCustomers extends JModelItem
{
	 public function __construct($config = array())
    {
       
        parent::__construct($config);
    }
    
    /**
     * get customer by id
     * @param $userid int from juser->id
     * return object customer
     **/
	public function getItemByUserId($userid){
		$db = JFactory::getDbo();
		$query->select('a.*');
		$query->from($db->quoteName('#__users','a'));
		$query->where($db->quoteName('a.id').' = '.intval($userid));
		$db->setQuery($query);
		//echo $db->getQuery();
		$profile = $db->loadObject();
		return $profile;
	}
	public function save($obj){
		jimport('joomla.user.helper');
		$salt   = JUserHelper::genRandomPassword(32);
		$crypted  = JUserHelper::getCryptedPassword($obj->password1, $salt);
		$cpassword = $crypted.':'.$salt;
		$customer_group_id = $this->getCustomerGroupId();
		$groups = array("1","2");
		$groups[] = $customer_group_id;
		$data = array(
		  "name"=>$obj->email,
		  "username"=>$obj->email,
		  "password"=>$obj->password1,
		  "password2"=>$obj->password1,
		  "email"=>$obj->email,
		  "block"=>0,
		  "groups"=>$groups
		);

		$user = new JUser;
		//Write to database
		if(!$user->bind($data)) {
		  throw new Exception("Could not bind data. Error: " . $user->getError());
		}
		if (!$user->save()) {
		  throw new Exception("Could not save user. Error: " . $user->getError());
		}
		
		return $user;
	}
	/**
	 * get a group id of a  customer
	 * return int group id of customer
	 */
	public function getCustomerGroupId(){
		$db = JFactory::getDbo();
		$db->setQuery(
			'SELECT `id`' .
			' FROM `#__usergroups`' .
			' WHERE `title` = '. $db->quote('Customer')
		);
		$groupId = $db->loadResult();
		if($groupId==null){
			throw new Exception('Please create a new group called Customer');
		}
		return $groupId;
	}
	/**
	 * check whether this user is a customer
	 * @param $user juser
	 * return boolean
	 */
	public function inCustomerGroup($user){
		$dealerGroupId = $this->getDealerGroupId();
		foreach ($user->groups as $groupId => $value){
			if($dealerGroupId==$groupId){
				return TRUE;
			}
		}
		return FALSE;
	}
	/**
	 * get all customers
	 * return array of customer
	 */
	public function getAllCustomers(){
		$customer_group_id = $this->getCustomerGroupId();
		jimport('joomla.access.access');
		jimport('joomla.user.user');
		$customers = JAccess::getUsersByGroup($customer_group_id);
		$result = NULL;
		if($customers!=NULL){
			$result = array();
			foreach($customers as $user_id) {
				$user = JFactory::getUser($user_id);
				$user->loggedin = $this->isLoggedIn($user_id);
				//remove domain from email/name
				$parts = explode('@',$user->name);
				$user->name = $parts[0];
				$result[] = $user;
			}
		}
		return $result;
	}
	/**
	 * check whether product advisor is logged in or not
	 * @param $userId
	 * return bool
	 */
	public function isLoggedIn($userId){
		$db = JFactory::getDbo();
		$query = $db->getQuery(TRUE);
		$query->select('session_id');
		$query->from($db->quoteName('#__session','a'));
		$query->where($db->quoteName('a.userid').' = '.intval($userId));
		$db->setQuery($query);
		$sessionid = $db->loadObject();
		if($sessionid==NULL){
			return FALSE;
		}
		return TRUE;
	}
}
